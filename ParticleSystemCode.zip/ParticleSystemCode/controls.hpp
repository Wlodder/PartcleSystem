void process_inputs();
glm::mat4 getViewMatrix();
glm::mat4 getProjectionMatrix();
float getGravityMultiplier();
float getSphereSize();
float getParticleLifeTime();
float getParticleDampening();
