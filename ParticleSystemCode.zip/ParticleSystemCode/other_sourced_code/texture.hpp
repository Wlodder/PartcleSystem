#pragma once

#include <glew.h>
#include <GLFW/glfw3.h>

GLuint loadDDS(const char* imagepath);